TARGET DECK: SEM4::Computer_Networks::7 History_NGN_Numbering

Telegraph? #flashcard 
![[Pasted image 20240429170604.png]]
<!--ID: 1714407125648-->


Teletypewriter? #flashcard 
![[Pasted image 20240429170943.png]]
Manual switching involves human operators physically making connections by plugging and unplugging cables to establish communication paths between devices or systems. Mechanical switching, on the other hand, typically refers to the use of mechanical devices or systems to automate the switching process, such as using relays or switches controlled by mechanical mechanisms. While both methods involve physical action, manual switching relies entirely on human operators, whereas mechanical switching incorporates automated mechanisms to perform the switching tasks.
<!--ID: 1714407125656-->



Telephone? #flashcard 
![[Pasted image 20240429171812.png]]
- "Fixed" refers to the fact that the telephone is permanently installed in a specific location, typically within a building or residence. It does not move from place to place and is connected to a specific telephone line.
- "Landline" indicates that the telephone is connected to the telecommunications network via physical cables, usually made of copper or fiber-optic materials, which are installed underground or on utility poles. This distinguishes it from mobile or cellular phones, which communicate wirelessly through radio waves.
<!--ID: 1714407125663-->



A classic fixed (landline) telephone network and its building blocks?  #flashcard 
![[Pasted image 20240429173059.png]]![[Pasted image 20240429173106.png]]
<!--ID: 1714407125670-->


Talk about NGN?
What is merging? 
Give a topological sketch? #flashcard 
![[Pasted image 20240429173455.png]]
ADSL stands for Asymmetric Digital Subscriber Line. It's a type of technology used to transmit digital data over traditional telephone lines, typically copper wires, for high-speed internet access. The "asymmetric" part means that it allows for faster download speeds than upload speeds. ADSL technology allows users to maintain their telephone service while also accessing the internet over the same line.
![[Pasted image 20240429173601.png]]
![[Pasted image 20240429173815.png]]
<!--ID: 1714407125676-->



Talk about numbering overall? #flashcard 
![[Pasted image 20240429175138.png]]
<!--ID: 1714407125685-->


National Destination Number? #flashcard 
![[Pasted image 20240429175204.png]]
<!--ID: 1714407125690-->


What id the diff between prefixes and short numbers? #flashcard 
![[Pasted image 20240429180539.png]]
<!--ID: 1714407125701-->


What are two numbering schemes? #flashcard 
![[Pasted image 20240429180557.png]]
<!--ID: 1714407125707-->


What moblie scheme of mobile numbers do we have in hungary? #flashcard 
![[Pasted image 20240429181159.png]]
<!--ID: 1714407125714-->


How wide should a voice channel be? #flashcard 
![[Pasted image 20240429181425.png]]
![[Pasted image 20240429181433.png]]
![[Pasted image 20240429181713.png]]
<!--ID: 1714407276428-->


Analog telephone systems? #flashcard 
![[Pasted image 20240429181751.png]]
<!--ID: 1714407719737-->



The expansion of digital technology? #flashcard 
![[Pasted image 20240429181946.png]]
<!--ID: 1714407719743-->


Digital telecommunication networks? #flashcard 
![[Pasted image 20240429182155.png]]
<!--ID: 1714407719751-->



