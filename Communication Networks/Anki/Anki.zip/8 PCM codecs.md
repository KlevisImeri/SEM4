TARGET DECK: SEM4::Computer_Networks::8 PCM codecs
What are some types of digital signals? #flashcard 
![[Pasted image 20240429182801.png]]
![[Pasted image 20240429182807.png]]
<!--ID: 1714408180725-->


What are some digital signals? #flashcard 
![[Pasted image 20240429182938.png]]
![[Pasted image 20240429182843.png]]
<!--ID: 1714408180731-->


All signals appearing on a physical medium are?
What’s the difference btw digital and binary?
![[Pasted image 20240429183041.png]]

Talk about PCM in general? #flashcard 
![[Pasted image 20240429183553.png]]
<!--ID: 1714408556437-->


Talk about A-D conversion steps of PCM? #flashcard 
![[Pasted image 20240429183829.png]]
![[Pasted image 20240429183839.png]]
![[Pasted image 20240429183956.png]]
![[Pasted image 20240429184431.png]]
![[Pasted image 20240429184532.png]]
![[Pasted image 20240429184338.png]]
<!--ID: 1714408736577-->

Draw the PCM and find the kb/s? #flashcard 
![[Pasted image 20240429184925.png]]
![[Pasted image 20240429185002.png]]
<!--ID: 1714410914926-->


Calculate PCM at CD? #flashcard 
![[Pasted image 20240429190836.png]]
<!--ID: 1714410914932-->



What is diff between encoding and line encoding? #flashcard 
- **Encoding**: Encoding the quantized samples into digital data for transmission or storage. This step involves assigning binary codes to the quantized samples to represent them digitally.
- **Line Encoding**: Further encoding the digital data into a format suitable for transmission over communication lines. Line encoding techniques convert digital data into signals that can be transmitted efficiently over communication channels, considering factors such as bandwidth, noise immunity, and clock recovery.
<!--ID: 1714410914936-->


What do you use for D-A conversion in PCM? #flashcard 
D-A conversion with the inverse characteristic of quantization
<!--ID: 1714410948333-->


Can you do a quick refresh? #flashcard 
![[Pasted image 20240429191647.png]]![[Pasted image 20240429191652.png]]![[Pasted image 20240429191703.png]]
<!--ID: 1714411035076-->


Codec features? #flashcard 
![[Pasted image 20240429192055.png]]
![[Pasted image 20240429192200.png]]
**Tandemizability**:
- Tandemizability refers to the ability of a codec to be used in combination with other codecs in a cascaded manner.
**Recoding**:
- Recoding refers to the process of encoding and decoding data multiple times, either with the same codec or with different codecs, to achieve a desired outcome.
<!--ID: 1714412433158-->


Codecs types and there Mean Opinion Score? #flashcard 
![[Pasted image 20240429193135.png]]
![[Pasted image 20240429193144.png]]
<!--ID: 1714412433164-->


What is one knows codec. Talk about it.
![[Pasted image 20240429193337.png]]


Tell the table with Codec Types? #flashcard 
![[Pasted image 20240429193515.png]]ISDN stands for Integrated Services Digital Network. It's a set of communication standards for simultaneous digital transmission of voice, video, data, and other network services over traditional telephone lines.
GSM (Global System for Mobile Communications)
<!--ID: 1714412433169-->

