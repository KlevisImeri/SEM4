TARGET DECK: SEM4::Computer_Networks::9 VoIP
Voice transmission in chronological order? #flashcard 
![[Pasted image 20240429194623.png]]
<!--ID: 1714412786811-->



Why VoIP is good? #flashcard 
![[Pasted image 20240429194803.png]]
<!--ID: 1714412891690-->

What are the challenges of VoIP? #flashcard 
![[Pasted image 20240429195332.png]]
<!--ID: 1714413669731-->



Talk about VoIP architectures? #flashcard 
![[Pasted image 20240429195353.png]]
![[Pasted image 20240429195401.png]]
DSL - digital subscriber line
![[Pasted image 20240429200022.png]]
A softphone refers to VoIP software that allows users to make voice calls over the internet using their computers or mobile devices.
![[Pasted image 20240429200104.png]]
<!--ID: 1714413669739-->



VoIP functions? #flashcard 
![[Pasted image 20240429200205.png]]
![[Pasted image 20240429200321.png]]
<!--ID: 1714413888877-->



Talk about IMS? #flashcard 
![[Pasted image 20240429200446.png]]
![[Pasted image 20240429201504.png]]
HSS stands for Home Subscriber Server.
![[Pasted image 20240429201723.png]]
<!--ID: 1714413888883-->


Talk about SIP general? #flashcard 
![[Pasted image 20240429202022.png]]
<!--ID: 1714415002675-->

Talk about SIP network components? #flashcard 
![[Pasted image 20240429202319.png]]
<!--ID: 1714415002680-->

Explain the Call Flow of SIP? #flashcard 
![[Pasted image 20240429202520.png]]
![[Pasted image 20240429202846.png]]
<!--ID: 1714415187372-->


Talk about SDP? #flashcard 
![[Pasted image 20240429202620.png]]
<!--ID: 1714415187377-->

What are types of SIP responses? #flashcard 
![[Pasted image 20240429202738.png]]
Something provisional is **temporary, in the sense that it's only valid for a while**.
<!--ID: 1714415550785-->
