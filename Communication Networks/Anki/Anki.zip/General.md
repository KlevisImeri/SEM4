

![[Pasted image 20240317221640.png]]

https://medium.datadriveninvestor.com/internet-educational-series-5-dhcp-dynamic-host-configuration-protocol-a35e09a0d263

Should that be a broadcast
![[Pasted image 20240317221939.png]]

- ipconfig/realease
- ipconfig /renew
- ipconfig /renew
- ipconfig/release
- ipconfig /renew